# Do DNS-01 verification using Route53

I was not about to implement this in BASH, sorry guys. I'd like you to have it, however.

It's pretty simple to use.

1. pip install boto3 dnspython
2. ln -s dns_route53.py dns_add_route53
3. ln -s dns_route53.py dns_del_route53
4. Use it just like the other scripts
